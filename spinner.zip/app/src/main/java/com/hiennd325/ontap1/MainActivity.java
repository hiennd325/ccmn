package com.hiennd325.ontap1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText edtMa, edtTen, edtGia;
    Spinner spnLoai;
    Button btnThem, btnSua, btnThongKe;
    ListView lvSanPham;
    ArrayList<SanPham> list = new ArrayList<>();
    ArrayAdapter<SanPham> adapter;
    int viTriChon = -1;
    DecimalFormat df = new DecimalFormat("###,###,### đ");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

        edtMa = findViewById(R.id.edtMa);
        edtTen = findViewById(R.id.edtTen);
        edtGia = findViewById(R.id.edtGia);
        spnLoai = findViewById(R.id.spnLoai);
        btnThem = findViewById(R.id.btnThem);
        btnSua = findViewById(R.id.btnSua);
        btnThongKe = findViewById(R.id.btnThongKe);
        lvSanPham = findViewById(R.id.lvSanPham);

        list.add(new SanPham("DT01", "Điện thoại Samsung", 10000000, "Điện tử"));
        list.add(new SanPham("GD01", "Tủ lạnh Panasonic", 12000000, "Gia dụng"));

        adapter = new ArrayAdapter<SanPham>(this, R.layout.item_sanpham, list) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_sanpham, parent, false);
                }
                SanPham sp = getItem(position);
                if (sp != null) {
                    TextView txtTen = convertView.findViewById(R.id.txtItemTen);
                    TextView txtGia = convertView.findViewById(R.id.txtItemGia);
                    TextView txtMa = convertView.findViewById(R.id.txtItemMa);
                    TextView txtLoai = convertView.findViewById(R.id.txtItemLoai);

                    txtTen.setText(sp.ten);
                    txtGia.setText(df.format(sp.gia));
                    txtMa.setText("Mã: " + sp.ma);
                    txtLoai.setText(sp.loai);
                }
                return convertView;
            }
        };
        lvSanPham.setAdapter(adapter);

        // a) Thêm
        btnThem.setOnClickListener(v -> {
            String ma = edtMa.getText().toString().trim();
            String ten = edtTen.getText().toString().trim();
            String giaStr = edtGia.getText().toString().trim();

            if (ma.isEmpty() || ten.isEmpty() || giaStr.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                long gia = Long.parseLong(giaStr);
                list.add(new SanPham(ma, ten, gia, spnLoai.getSelectedItem().toString()));
                adapter.notifyDataSetChanged();
                xoaTrang();
                Toast.makeText(this, "Thêm sản phẩm thành công!", Toast.LENGTH_SHORT).show();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Giá phải là số hợp lệ!", Toast.LENGTH_SHORT).show();
            }
        });

        // b) Chọn trên ListView
        lvSanPham.setOnItemClickListener((p, view, pos, id) -> {
            viTriChon = pos;
            SanPham sp = list.get(pos);
            edtMa.setText(sp.ma);
            edtTen.setText(sp.ten);
            edtGia.setText(String.valueOf(sp.gia));
            ArrayAdapter spAdapter = (ArrayAdapter) spnLoai.getAdapter();
            spnLoai.setSelection(spAdapter.getPosition(sp.loai));
        });

        // b) Sửa
        btnSua.setOnClickListener(v -> {
            if (viTriChon != -1) {
                String ma = edtMa.getText().toString().trim();
                String ten = edtTen.getText().toString().trim();
                String giaStr = edtGia.getText().toString().trim();

                if (ma.isEmpty() || ten.isEmpty() || giaStr.isEmpty()) {
                    Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    SanPham sp = list.get(viTriChon);
                    sp.ma = ma;
                    sp.ten = ten;
                    sp.gia = Long.parseLong(giaStr);
                    sp.loai = spnLoai.getSelectedItem().toString();
                    adapter.notifyDataSetChanged();
                    xoaTrang();
                    viTriChon = -1;
                    Toast.makeText(this, "Cập nhật thành công!", Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Giá phải là số hợp lệ!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Vui lòng chọn sản phẩm cần sửa!", Toast.LENGTH_SHORT).show();
            }
        });

        // c) Thống kê
        btnThongKe.setOnClickListener(v -> {
            long tongGia = 0;
            for (SanPham sp : list) tongGia += sp.gia;
            new AlertDialog.Builder(this)
                .setTitle("Thống kê sản phẩm")
                .setMessage("• Tổng số lượng: " + list.size() + " sản phẩm\n• Tổng giá trị: " + df.format(tongGia))
                .setPositiveButton("Đóng", null)
                .show();
        });
    }

    private void xoaTrang() {
        edtMa.setText("");
        edtTen.setText("");
        edtGia.setText("");
        spnLoai.setSelection(0);
        edtMa.requestFocus();
    }
}
