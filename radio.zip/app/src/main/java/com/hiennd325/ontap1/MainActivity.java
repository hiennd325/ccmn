package com.hiennd325.ontap1;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText edtMa, edtTen, edtGia;
    RadioGroup rgLoai;
    RadioButton rbDienTu, rbGiaDung, rbThucPham;
    Button btnThem, btnSua, btnThongKe;
    ListView lvSanPham;
    ArrayList<SanPham> list = new ArrayList<>();
    ArrayAdapter<SanPham> adapter;
    int viTriChon = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

        edtMa = findViewById(R.id.edtMa);
        edtTen = findViewById(R.id.edtTen);
        edtGia = findViewById(R.id.edtGia);
        rgLoai = findViewById(R.id.rgLoai);
        rbDienTu = findViewById(R.id.rbDienTu);
        rbGiaDung = findViewById(R.id.rbGiaDung);
        rbThucPham = findViewById(R.id.rbThucPham);
        btnThem = findViewById(R.id.btnThem);
        btnSua = findViewById(R.id.btnSua);
        btnThongKe = findViewById(R.id.btnThongKe);
        lvSanPham = findViewById(R.id.lvSanPham);

        list.add(new SanPham("DT01", "Điện thoại Samsung", 10000000, "Điện tử"));
        list.add(new SanPham("GD01", "Tủ lạnh Panasonic", 12000000, "Gia dụng"));

        adapter = new ArrayAdapter<SanPham>(this, R.layout.item_san_pham, list) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if (convertView == null) {
                    convertView = getLayoutInflater().inflate(R.layout.item_san_pham, parent, false);
                }
                SanPham sp = getItem(position);
                if (sp != null) {
                    TextView tvTen = convertView.findViewById(R.id.tvItemTen);
                    TextView tvMa = convertView.findViewById(R.id.tvItemMa);
                    TextView tvLoai = convertView.findViewById(R.id.tvItemLoai);
                    TextView tvGia = convertView.findViewById(R.id.tvItemGia);

                    tvTen.setText(sp.ten);
                    tvMa.setText(sp.ma);
                    tvLoai.setText(sp.loai);
                    tvGia.setText(String.format("%,d đ", sp.gia));
                }
                return convertView;
            }
        };
        lvSanPham.setAdapter(adapter);

        // a) Thêm
        btnThem.setOnClickListener(v -> {
            String ma = edtMa.getText().toString().trim();
            String ten = edtTen.getText().toString().trim();
            String strGia = edtGia.getText().toString().trim();
            if (ma.isEmpty() || ten.isEmpty() || strGia.isEmpty()) return;

            RadioButton rb = findViewById(rgLoai.getCheckedRadioButtonId());
            list.add(new SanPham(ma, ten, Long.parseLong(strGia), rb.getText().toString()));
            adapter.notifyDataSetChanged();
            edtMa.setText("");
            edtTen.setText("");
            edtGia.setText("");
        });

        // b) Chọn trên ListView
        lvSanPham.setOnItemClickListener((p, view, pos, id) -> {
            viTriChon = pos;
            SanPham sp = list.get(pos);
            edtMa.setText(sp.ma);
            edtTen.setText(sp.ten);
            edtGia.setText(String.valueOf(sp.gia));

            if (sp.loai.equals("Điện tử")) rbDienTu.setChecked(true);
            else if (sp.loai.equals("Gia dụng")) rbGiaDung.setChecked(true);
            else rbThucPham.setChecked(true);
        });

        // b) Sửa
        btnSua.setOnClickListener(v -> {
            if (viTriChon != -1) {
                String ma = edtMa.getText().toString().trim();
                String ten = edtTen.getText().toString().trim();
                String strGia = edtGia.getText().toString().trim();
                if (ma.isEmpty() || ten.isEmpty() || strGia.isEmpty()) return;

                SanPham sp = list.get(viTriChon);
                sp.ma = ma;
                sp.ten = ten;
                sp.gia = Long.parseLong(strGia);
                RadioButton rb = findViewById(rgLoai.getCheckedRadioButtonId());
                sp.loai = rb.getText().toString();
                adapter.notifyDataSetChanged();
            }
        });

        // c) Thống kê
        btnThongKe.setOnClickListener(v -> {
            long tongGia = 0;
            for (SanPham sp : list) tongGia += sp.gia;
            new AlertDialog.Builder(this)
                .setTitle("Thống kê")
                .setMessage("Tổng số SP: " + list.size() + "\nTổng tiền: " + String.format("%,d đ", tongGia))
                .setPositiveButton("OK", null)
                .show();
        });
    }
}
